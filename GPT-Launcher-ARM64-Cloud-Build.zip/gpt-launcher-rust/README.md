# GPT Launcher — ARM64 prototype

Android 10+ Rust/Android packaging prototype. MojoLauncher is the intended feature baseline; Horizon is a Rust/Android reference.

## Build an APK

1. Upload the contents of this project folder to the root of the `Ayushh` GitHub repository (keep the `.github/workflows/android.yml` file).
2. Open the repository's **Actions** tab.
3. Select **GPT Launcher Android Build** and run the workflow (or push a commit to `main`).
4. When it succeeds, open the run and download the `GPT-Launcher-ARM64-prototype` artifact.

## Honest implementation status

This is an early packaging prototype, not the finished launcher. The Rust NativeActivity entry point currently initializes logging only. Mojo launcher screens, account/session handling, version installation, Java runtime management, Minecraft launching, Holy GL4ES rendering, and the four-slot touch-control UI/input bridge are not implemented yet. This APK is not expected to launch Minecraft.

The Mojo-derived Rust core currently models and round-trips the four-slot control layout. The full Mojo Java/native subsystems and required external components still need migration and integration.
